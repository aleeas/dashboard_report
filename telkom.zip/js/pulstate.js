
$(function () {
    $(".pulse1").pulsate({glow:false});
    $(".pulse2").pulsate({color:"#45ae7a"});
    $(".pulse3").pulsate({reach:50,color: "#8f67b1"});
    $(".pulse4").pulsate({speed:2500,color: "#ecc200"});
    $(".pulse5").pulsate({pause:1000, color: "#f05050"});
    $(".pulse6").pulsate({onHover:true,color: "#119dc9"});
});
